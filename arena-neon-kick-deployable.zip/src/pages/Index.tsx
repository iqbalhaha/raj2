import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import BookingSection from '@/components/BookingSection';
import GallerySection from '@/components/GallerySection';
import TestimonialsSection from '@/components/TestimonialsSection';
import PricingSection from '@/components/PricingSection';
import ContactMapSection from '@/components/ContactMapSection';

const Index = () => {
  useEffect(() => {
    // Animation on scroll logic
    const animateOnScroll = () => {
      const elements = document.querySelectorAll('.animate-on-scroll');
      elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementBottom = element.getBoundingClientRect().bottom;
        const isVisible = (elementTop < window.innerHeight - 100) && (elementBottom > 0);
        
        if (isVisible) {
          element.classList.add('is-visible');
        }
      });
    };
    
    // Initial call
    animateOnScroll();
    
    // Event listener for scroll
    window.addEventListener('scroll', animateOnScroll);
    
    // Cleanup
    return () => {
      window.removeEventListener('scroll', animateOnScroll);
    };
  }, []);

  // Preload key assets
  useEffect(() => {
    const preloadImages = [
      '/hero-bg.png',
      '/turf-texture.png',
      '/placeholder.svg'
    ];
    
    preloadImages.forEach(image => {
      const img = new Image();
      img.src = image;
    });
    
    // Preload video
    const videoElement = document.createElement('link');
    videoElement.rel = 'preload';
    videoElement.href = '/hero-video.mp4';
    videoElement.as = 'video';
    document.head.appendChild(videoElement);
  }, []);
  
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      
      <main>
        <HeroSection />
        <AboutSection />
        <BookingSection />
        <GallerySection />
        <TestimonialsSection />
        <PricingSection />
        <ContactMapSection />
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
