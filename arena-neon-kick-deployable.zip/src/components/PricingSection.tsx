
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

type PricingPlan = {
  id: number;
  name: string;
  price: number;
  duration: string;
  features: string[];
  isPopular?: boolean;
};

const PricingSection = () => {
  const [visibleItems, setVisibleItems] = useState<number[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0');
            setVisibleItems(prev => [...prev, index]);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const elements = document.querySelectorAll('.pricing-card');
    elements.forEach(el => observer.observe(el));
    
    return () => {
      elements.forEach(el => observer.unobserve(el));
    };
  }, []);

  const pricingPlans: PricingPlan[] = [
    {
      id: 1,
      name: "Casual Play",
      price: 1200,
      duration: "per hour",
      features: [
        "5-a-side field",
        "Standard lighting",
        "Changing room access",
        "Water dispenser"
      ]
    },
    {
      id: 2,
      name: "Tournament",
      price: 8000,
      duration: "per day",
      features: [
        "Full-size field for 7-a-side",
        "Premium lighting system",
        "Changing rooms with lockers",
        "Referee services",
        "Basic scoreboard"
      ],
      isPopular: true
    },
    {
      id: 3,
      name: "Professional",
      price: 15000,
      duration: "per day",
      features: [
        "Full-size field for 11-a-side",
        "Stadium-quality lighting",
        "Deluxe changing facilities",
        "Referee & linesmen services",
        "Digital scoreboard",
        "Live streaming setup",
        "Post-match recovery area"
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[linear-gradient(45deg,rgba(255,255,255,0.1)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.1)_50%,rgba(255,255,255,0.1)_75%,transparent_75%,transparent)] bg-[size:20px_20px]"></div>
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-neon-green rounded-full blur-3xl opacity-10"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-neon-purple rounded-full blur-3xl opacity-10"></div>
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">PRICING PLANS</h2>
          <p className="section-subheading max-w-3xl mx-auto">
            Choose the perfect plan for your game. We offer different packages to suit every need and budget.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <div 
              key={plan.id} 
              data-index={index}
              className={`pricing-card glass-card rounded-lg overflow-hidden transition-all duration-700 transform ${
                visibleItems.includes(index) 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-20'
              }`}
              style={{ transitionDelay: `${index * 0.2}s` }}
            >
              {/* Popular Badge */}
              {plan.isPopular && (
                <div className="bg-neon-green text-black font-bold py-1 px-4 text-center">
                  Most Popular
                </div>
              )}
              
              <div className={`p-6 ${plan.isPopular ? 'pt-4' : ''}`}>
                <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold neon-text-green">৳{plan.price}</span>
                  <span className="text-gray-400 ml-1">{plan.duration}</span>
                </div>
                
                <div className="border-t border-gray-700 my-6"></div>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        className="h-5 w-5 text-neon-green mr-2 mt-0.5"
                        viewBox="0 0 20 20" 
                        fill="currentColor"
                      >
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full ${
                    plan.isPopular 
                      ? 'neo-button' 
                      : 'bg-gray-800 hover:bg-gray-700 text-white'
                  }`}
                >
                  Select Plan
                </Button>
              </div>
              
              {/* Bottom Border Glow */}
              {plan.isPopular && (
                <div className="h-1 bg-gradient-to-r from-neon-blue via-neon-green to-neon-blue"></div>
              )}
            </div>
          ))}
        </div>
        
        {/* Corporate Plans */}
        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold neon-text-blue mb-4">Corporate & Special Events</h3>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Looking to host a corporate event, team building activity, or special celebration? 
            We offer customized packages tailored to your specific requirements.
          </p>
          <Button className="bg-neon-blue hover:bg-blue-600 text-black font-semibold px-6 py-3 rounded-lg transition-colors">
            Get Custom Quote
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
