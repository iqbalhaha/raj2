
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    setIsVisible(true);
  }, []);
  
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('booking');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  const scrollToGallery = () => {
    const gallerySection = document.getElementById('gallery');
    if (gallerySection) {
      gallerySection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return <section id="home" className="relative min-h-screen overflow-hidden flex items-center justify-center">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black z-10"></div>
        <div className="absolute inset-0 bg-black/40 z-10"></div>
        <video className="w-full h-full object-cover" autoPlay muted loop playsInline>
          <source src="/hero-video.mp4" type="video/mp4" />
          {/* Fallback image for browsers that don't support video */}
          <img src="/placeholder.svg" alt="Football players in action" className="w-full h-full object-cover" />
        </video>
      </div>
      
      {/* Animated Overlay Elements */}
      <div className="absolute inset-0 z-10 overflow-hidden">
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-neon-green rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-neon-blue rounded-full blur-3xl opacity-20 animate-float"></div>
        
        {/* Geometric Lines */}
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-1/4 left-0 w-full h-px bg-white/10"></div>
          <div className="absolute top-2/4 left-0 w-full h-px bg-white/10"></div>
          <div className="absolute top-3/4 left-0 w-full h-px bg-white/10"></div>
          <div className="absolute top-0 left-1/4 w-px h-full bg-white/10"></div>
          <div className="absolute top-0 left-2/4 w-px h-full bg-white/10"></div>
          <div className="absolute top-0 left-3/4 w-px h-full bg-white/10"></div>
        </div>
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 z-20 text-center">
        <div className={`transition-all duration-1000 transform ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-4 neon-text-green">RAJSHAHI TURF</h1>
          
          <h2 className="text-2xl md:text-3xl mb-8 text-white animate-pulse">
            WHERE LEGENDS KICK OFF
          </h2>
          
          <p className="text-lg text-gray-300 max-w-3xl mx-auto mb-10">
            Experience the future of football on Bangladesh's most advanced turf. 
            State-of-the-art facilities, professional lighting, and an atmosphere 
            that electrifies every match.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Button 
              className="neo-button text-lg group relative overflow-hidden"
              onClick={scrollToBooking}
            >
              <span className="relative z-10">Book Your Game</span>
              <span className="absolute inset-0 w-full h-full bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
            </Button>
            
            <Button 
              variant="outline" 
              className="border-neon-blue text-neon-blue hover:bg-neon-blue/10 text-lg"
              onClick={scrollToGallery}
            >
              Take A Tour
            </Button>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
          <span className="text-white/70 mb-2">Scroll Down</span>
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center p-1">
            <div className="w-1 h-2 bg-white rounded-full animate-bounce-slow"></div>
          </div>
        </div>
      </div>
    </section>;
};

export default HeroSection;
