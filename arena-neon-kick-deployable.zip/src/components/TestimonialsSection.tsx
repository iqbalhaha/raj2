
import { useState, useEffect } from 'react';

type Testimonial = {
  id: number;
  name: string;
  avatar: string;
  role: string;
  content: string;
  rating: number;
};

const TestimonialsSection = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );
    
    const section = document.querySelector('#testimonials');
    if (section) {
      observer.observe(section);
    }
    
    return () => {
      if (section) {
        observer.unobserve(section);
      }
    };
  }, []);

  useEffect(() => {
    // Auto rotate testimonials
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Rafiq Ahmed",
      avatar: "/placeholder.svg",
      role: "Local Club Captain",
      content: "Playing at Rajshahi Turf Arena is a whole new experience. The quality of the turf and the lighting system makes it feel like we're playing in a professional stadium. My team loves the facilities!",
      rating: 5
    },
    {
      id: 2,
      name: "Nasreen Khan",
      avatar: "/placeholder.svg",
      role: "Football Coach",
      content: "As a coach, I appreciate the attention to detail in this arena. The turf is maintained perfectly, and the staff is always helpful. My students have shown remarkable improvement practicing here.",
      rating: 5
    },
    {
      id: 3,
      name: "Tariq Hasan",
      avatar: "/placeholder.svg",
      role: "Amateur Player",
      content: "The booking system is so convenient! I can easily book slots for my weekend games with friends. The refreshment area is also a great addition for post-match gatherings.",
      rating: 4
    },
    {
      id: 4,
      name: "Fatima Rahman",
      avatar: "/placeholder.svg",
      role: "Tournament Organizer",
      content: "Organized our college tournament here and it was a massive success. The management team was extremely professional and accommodating. Will definitely be back for future events!",
      rating: 5
    }
  ];

  return (
    <section id="testimonials" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[radial-gradient(circle,_rgba(255,255,255,0.1)_1px,_transparent_1px)] bg-[length:20px_20px]"></div>
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-neon-blue rounded-full blur-3xl opacity-10"></div>
        <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-neon-purple rounded-full blur-3xl opacity-10"></div>
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">PLAYER REVIEWS</h2>
          <p className="section-subheading max-w-3xl mx-auto">
            Don't just take our word for it. See what our players and visitors have to say about their Rajshahi Turf Arena experience.
          </p>
        </div>
        
        {/* Testimonials Slider */}
        <div 
          className={`relative max-w-4xl mx-auto transition-opacity duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
        >
          <div className="relative">
            {testimonials.map((testimonial, index) => (
              <div 
                key={testimonial.id}
                className={`transition-all duration-700 ${
                  activeIndex === index 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 absolute top-0 left-0 translate-y-8'
                }`}
              >
                <div className="glass-card p-8 rounded-lg relative">
                  {/* Quote marks */}
                  <div className="absolute top-6 left-6 text-6xl text-neon-green opacity-20">"</div>
                  <div className="absolute bottom-6 right-6 text-6xl text-neon-green opacity-20">"</div>
                  
                  {/* Content */}
                  <div className="relative z-10">
                    <p className="text-gray-300 text-lg leading-relaxed mb-6">
                      {testimonial.content}
                    </p>
                    
                    <div className="flex items-center">
                      <div className="mr-4 relative">
                        <div className="w-12 h-12 rounded-full overflow-hidden">
                          <img 
                            src={testimonial.avatar} 
                            alt={testimonial.name} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="absolute -inset-1 rounded-full animate-pulse opacity-50 bg-neon-blue blur-md -z-10"></div>
                      </div>
                      
                      <div>
                        <h4 className="text-white font-bold">{testimonial.name}</h4>
                        <p className="text-gray-400 text-sm">{testimonial.role}</p>
                      </div>
                      
                      <div className="ml-auto">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <svg
                              key={i}
                              xmlns="http://www.w3.org/2000/svg"
                              className={`h-5 w-5 ${i < testimonial.rating ? 'text-neon-green' : 'text-gray-600'}`}
                              viewBox="0 0 20 20"
                              fill="currentColor"
                            >
                              <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                              />
                            </svg>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Navigation Dots */}
          <div className="flex justify-center mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full mx-2 transition-all duration-300 ${
                  activeIndex === index 
                    ? 'bg-neon-green w-8' 
                    : 'bg-white/30 hover:bg-white/50'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
        
        {/* User Review Form */}
        <div className={`mt-20 max-w-xl mx-auto transition-all duration-1000 transform ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`} style={{transitionDelay: '0.3s'}}>
          <div className="glass-card p-6 rounded-lg">
            <h3 className="text-xl font-bold text-white mb-4">Share Your Experience</h3>
            <form>
              <div className="mb-4">
                <label className="block text-gray-300 mb-2">Your Name</label>
                <input 
                  type="text" 
                  className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-neon-green"
                  placeholder="Enter your name"
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-300 mb-2">Your Review</label>
                <textarea 
                  className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-neon-green"
                  placeholder="Tell us about your experience..."
                  rows={4}
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-300 mb-2">Rating</label>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      type="button"
                      className="w-8 h-8 text-gray-400 hover:text-neon-green focus:outline-none"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                        />
                      </svg>
                    </button>
                  ))}
                </div>
              </div>
              <button 
                type="submit" 
                className="bg-neon-blue hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
              >
                Submit Review
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
