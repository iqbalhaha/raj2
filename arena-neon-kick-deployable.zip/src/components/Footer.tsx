
import { Instagram, Facebook, Youtube } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-black py-12 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-neon-green animate-pulse"></div>
        <div className="absolute top-40 right-20 w-40 h-40 rounded-full bg-neon-blue animate-pulse"></div>
        <div className="absolute bottom-10 left-1/4 w-30 h-30 rounded-full bg-neon-purple animate-pulse"></div>
      </div>
      
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Logo and Description */}
          <div>
            <div className="flex items-center mb-4">
              <div className="relative">
                <img 
                  src="/placeholder.svg" 
                  alt="Rajshahi Turf Arena Logo" 
                  className="h-10 w-auto"
                />
                <div className="absolute -inset-1 rounded-full animate-pulse opacity-50 bg-neon-green blur-md -z-10"></div>
              </div>
              <h2 className="ml-3 text-lg font-bold neon-text-green">RAJSHAHI TURF ARENA</h2>
            </div>
            <p className="text-gray-400 mb-4">Where legends kick off. Experience the future of football at Rajshahi's premier turf arena.</p>
            <div className="flex space-x-4">
              <SocialLink href="https://facebook.com" icon={<Facebook size={20} />} />
              <SocialLink href="https://instagram.com" icon={<Instagram size={20} />} />
              <SocialLink href="https://youtube.com" icon={<Youtube size={20} />} />
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Quick Links</h3>
            <div className="flex flex-col space-y-2">
              <FooterLink href="#home">Home</FooterLink>
              <FooterLink href="#about">About Us</FooterLink>
              <FooterLink href="#booking">Booking</FooterLink>
              <FooterLink href="#gallery">Gallery</FooterLink>
              <FooterLink href="#testimonials">Reviews</FooterLink>
            </div>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Contact Us</h3>
            <div className="flex flex-col space-y-2 text-gray-400">
              <p>Rajshahi, Bangladesh</p>
              <p>Phone: +880 1XXX-XXXXXX</p>
              <p>Email: info@rajshahiturf.com</p>
              <p>Open: 9:00 AM - 11:00 PM</p>
            </div>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Subscribe</h3>
            <p className="text-gray-400 mb-4">Get updates on promotions and events</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-gray-800 text-white px-4 py-2 rounded-l-lg focus:outline-none focus:ring-1 focus:ring-neon-green"
              />
              <button className="bg-neon-green text-black px-4 py-2 rounded-r-lg font-semibold hover:bg-opacity-90 transition-all">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        
        {/* Sponsors */}
        <div className="mt-12 py-6 border-t border-gray-800">
          <h4 className="text-center text-white mb-4">Our Sponsors</h4>
          <div className="flex flex-wrap justify-center gap-8">
            {[1, 2, 3, 4].map((index) => (
              <div key={index} className="relative grayscale hover:grayscale-0 transition-all duration-500">
                <img 
                  src="/placeholder.svg" 
                  alt={`Sponsor ${index}`}
                  className="h-12 w-auto"
                />
                <div className="absolute -inset-1 opacity-0 hover:opacity-50 bg-neon-blue blur-md -z-10 transition-opacity duration-500"></div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Copyright */}
        <div className="mt-8 text-center text-gray-600">
          <p>&copy; {currentYear} Rajshahi Turf Arena. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

const SocialLink = ({ href, icon }: { href: string, icon: React.ReactNode }) => (
  <a 
    href={href} 
    target="_blank"
    rel="noopener noreferrer"
    className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-800 text-white hover:bg-neon-green hover:text-black transition-all duration-300"
  >
    {icon}
  </a>
);

const FooterLink = ({ href, children }: { href: string, children: React.ReactNode }) => (
  <a 
    href={href} 
    className="text-gray-400 hover:text-neon-green transition-colors duration-300"
  >
    {children}
  </a>
);

export default Footer;
