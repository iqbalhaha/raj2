
import { useState, useEffect } from 'react';

const SoundToggle = () => {
  const [isMuted, setIsMuted] = useState(true);
  const [audio] = useState(new Audio('/ambient.mp3'));
  
  useEffect(() => {
    audio.loop = true;
    
    return () => {
      audio.pause();
      audio.currentTime = 0;
    };
  }, [audio]);
  
  useEffect(() => {
    if (isMuted) {
      audio.pause();
    } else {
      audio.play().catch(error => {
        // Handle autoplay restrictions
        console.log("Autoplay restricted:", error);
        setIsMuted(true);
      });
    }
  }, [isMuted, audio]);
  
  const toggleSound = () => {
    setIsMuted(!isMuted);
  };
  
  return (
    <button 
      onClick={toggleSound}
      className="fixed bottom-6 right-6 z-50 w-12 h-12 rounded-full bg-black/40 backdrop-blur-lg border border-white/10 flex items-center justify-center text-white hover:bg-black/60 transition-all"
      aria-label={isMuted ? "Enable sound" : "Disable sound"}
    >
      {isMuted ? (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
        </svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
        </svg>
      )}
      
      {/* Animation circles */}
      {!isMuted && (
        <>
          <span className="absolute inset-0 rounded-full animate-ping opacity-20 bg-neon-blue"></span>
          <span className="absolute inset-2 rounded-full animate-pulse opacity-50 bg-neon-blue"></span>
        </>
      )}
    </button>
  );
};

export default SoundToggle;
