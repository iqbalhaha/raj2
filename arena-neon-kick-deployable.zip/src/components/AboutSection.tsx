
import { useEffect, useState } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { Award, MapPin, Users, Calendar } from 'lucide-react';

const AboutSection = () => {
  const [visibleItems, setVisibleItems] = useState<number[]>([]);
  const isMobile = useIsMobile();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0');
            setVisibleItems(prev => [...prev, index]);
          }
        });
      },
      { threshold: 0.2 }
    );
    
    const elements = document.querySelectorAll('.about-animate-item');
    elements.forEach(el => observer.observe(el));
    
    return () => {
      elements.forEach(el => observer.unobserve(el));
    };
  }, []);

  const features = [
    {
      icon: <Award className="text-neon-green" size={40} />,
      title: "Premium Quality Turf",
      description: "FIFA-approved synthetic turf with shock absorption technology for optimal performance and safety."
    },
    {
      icon: <MapPin className="text-neon-green" size={40} />,
      title: "Prime Location",
      description: "Conveniently located in the heart of Rajshahi with ample parking space and easy accessibility."
    },
    {
      icon: <Users className="text-neon-green" size={40} />,
      title: "Spectator Facilities",
      description: "Comfortable seating for spectators with refreshment options to enhance the match experience."
    },
    {
      icon: <Calendar className="text-neon-green" size={40} />,
      title: "Flexible Booking",
      description: "Easy online booking system with flexible time slots from early morning until late night."
    }
  ];
  
  return (
    <section id="about" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-full h-full bg-turf-pattern opacity-5"></div>
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-neon-green rounded-full blur-3xl opacity-10"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-neon-blue rounded-full blur-3xl opacity-10"></div>
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">ABOUT OUR ARENA</h2>
          <p className="section-subheading max-w-3xl mx-auto">
            Rajshahi Turf Arena is the premier destination for football enthusiasts in Bangladesh, 
            offering state-of-the-art facilities in a futuristic environment.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          {/* About Content */}
          <div>
            <h3 className="text-2xl font-bold mb-6 text-neon-blue">The Future of Football is Here</h3>
            <p className="text-gray-300 mb-6">
              Established in 2023, Rajshahi Turf Arena revolutionizes the football experience 
              in Bangladesh with cutting-edge technology and world-class amenities.
            </p>
            <p className="text-gray-300 mb-6">
              Our FIFA-standard synthetic turf provides the perfect playing surface in all weather 
              conditions, while our advanced LED lighting system creates a stadium-like atmosphere 
              for night games.
            </p>
            <p className="text-gray-300 mb-6">
              Whether you're a casual player looking for a friendly match or a competitive team 
              seeking tournament facilities, our arena offers the ultimate football experience.
            </p>
            <div className="grid grid-cols-2 gap-6 mt-8">
              <div className="text-center">
                <h4 className="text-4xl font-bold neon-text-green mb-2">5+</h4>
                <p className="text-gray-400">Professional Fields</p>
              </div>
              <div className="text-center">
                <h4 className="text-4xl font-bold neon-text-green mb-2">24/7</h4>
                <p className="text-gray-400">Online Booking</p>
              </div>
              <div className="text-center">
                <h4 className="text-4xl font-bold neon-text-green mb-2">100+</h4>
                <p className="text-gray-400">Tournaments Hosted</p>
              </div>
              <div className="text-center">
                <h4 className="text-4xl font-bold neon-text-green mb-2">1000+</h4>
                <p className="text-gray-400">Happy Players</p>
              </div>
            </div>
          </div>
          
          {/* Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-lg aspect-video">
              <img
                src="/placeholder.svg"
                alt="Rajshahi Turf Arena"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-neon-green/20 to-transparent"></div>
            </div>
            {/* Floating Elements */}
            <div className="absolute -top-10 -right-10 w-20 h-20 rounded-full border border-neon-green animate-spin-slow"></div>
            <div className="absolute -bottom-6 -left-6 w-12 h-12 rounded-full bg-neon-blue/30 animate-pulse"></div>
          </div>
        </div>
        
        {/* Features */}
        <div className="mt-24">
          <h3 className="text-2xl font-bold text-center mb-12 neon-text-blue">OUR FACILITIES</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index}
                className={`about-animate-item glass-card p-6 rounded-lg transition-all duration-700 ${
                  visibleItems.includes(index) ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'
                }`}
                data-index={index}
              >
                <div className="mb-4 relative">
                  {feature.icon}
                  <div className="absolute -inset-1 opacity-50 bg-neon-green blur-md -z-10 rounded-full"></div>
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{feature.title}</h4>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
