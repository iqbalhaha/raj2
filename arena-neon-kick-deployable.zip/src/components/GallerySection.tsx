
import { useState, useEffect } from 'react';

type GalleryItem = {
  id: number;
  type: 'image' | 'video';
  thumbnail: string;
  url: string;
  title: string;
};

const GallerySection = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'images' | 'videos'>('all');
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);
  const [visibleItems, setVisibleItems] = useState<number[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0');
            setVisibleItems(prev => [...prev, index]);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const elements = document.querySelectorAll('.gallery-item');
    elements.forEach(el => observer.observe(el));
    
    return () => {
      elements.forEach(el => observer.unobserve(el));
    };
  }, []);

  // Sample gallery items
  const galleryItems: GalleryItem[] = [
    {
      id: 1,
      type: 'image',
      thumbnail: '/placeholder.svg',
      url: '/placeholder.svg',
      title: 'Night match under stadium lights'
    },
    {
      id: 2,
      type: 'image',
      thumbnail: '/placeholder.svg',
      url: '/placeholder.svg',
      title: 'Aerial view of the arena'
    },
    {
      id: 3,
      type: 'video',
      thumbnail: '/placeholder.svg',
      url: '/video-placeholder.mp4',
      title: 'Tournament highlights'
    },
    {
      id: 4,
      type: 'image',
      thumbnail: '/placeholder.svg',
      url: '/placeholder.svg',
      title: 'Premium turf quality'
    },
    {
      id: 5,
      type: 'image',
      thumbnail: '/placeholder.svg',
      url: '/placeholder.svg',
      title: 'Team celebration'
    },
    {
      id: 6,
      type: 'video',
      thumbnail: '/placeholder.svg',
      url: '/video-placeholder.mp4',
      title: 'Slow-motion goal replay'
    },
    {
      id: 7,
      type: 'image',
      thumbnail: '/placeholder.svg',
      url: '/placeholder.svg',
      title: 'Refreshment area'
    },
    {
      id: 8,
      type: 'image',
      thumbnail: '/placeholder.svg',
      url: '/placeholder.svg',
      title: 'Spectator view'
    }
  ];

  const filteredItems = galleryItems.filter(item => {
    if (activeTab === 'all') return true;
    if (activeTab === 'images') return item.type === 'image';
    if (activeTab === 'videos') return item.type === 'video';
    return true;
  });

  const openLightbox = (item: GalleryItem) => {
    setSelectedItem(item);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    setSelectedItem(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <section id="gallery" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[linear-gradient(to_right,rgba(255,255,255,0.1)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-neon-green rounded-full blur-3xl opacity-10"></div>
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-neon-blue rounded-full blur-3xl opacity-10"></div>
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">OUR GALLERY</h2>
          <p className="section-subheading max-w-3xl mx-auto">
            Experience the electrifying atmosphere of Rajshahi Turf Arena through our gallery of images and videos.
          </p>
        </div>
        
        {/* Filter Tabs */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex bg-gray-900/50 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-md transition-all duration-300 ${
                activeTab === 'all' 
                  ? 'bg-neon-green text-black font-medium' 
                  : 'text-white hover:bg-white/10'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setActiveTab('images')}
              className={`px-4 py-2 rounded-md transition-all duration-300 ${
                activeTab === 'images' 
                  ? 'bg-neon-green text-black font-medium' 
                  : 'text-white hover:bg-white/10'
              }`}
            >
              Images
            </button>
            <button
              onClick={() => setActiveTab('videos')}
              className={`px-4 py-2 rounded-md transition-all duration-300 ${
                activeTab === 'videos' 
                  ? 'bg-neon-green text-black font-medium' 
                  : 'text-white hover:bg-white/10'
              }`}
            >
              Videos
            </button>
          </div>
        </div>
        
        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item, index) => (
            <div 
              key={item.id}
              data-index={index}
              className={`gallery-item relative group overflow-hidden rounded-lg cursor-pointer transition-transform duration-500 transform ${
                visibleItems.includes(index) ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
              }`}
              onClick={() => openLightbox(item)}
              style={{ 
                transitionDelay: `${index * 0.1}s`,
                aspectRatio: '4/3'
              }}
            >
              {/* Thumbnail */}
              <img 
                src={item.thumbnail} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                <p className="text-white font-medium">{item.title}</p>
              </div>
              
              {/* Video Icon */}
              {item.type === 'video' && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-14 h-14 rounded-full bg-black/50 flex items-center justify-center">
                    <div className="w-0 h-0 border-y-8 border-y-transparent border-l-12 border-l-white ml-1"></div>
                  </div>
                </div>
              )}
              
              {/* Glow Effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute inset-0 border-2 border-neon-blue"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Lightbox */}
      {lightboxOpen && selectedItem && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="max-w-4xl w-full">
            {selectedItem.type === 'image' ? (
              <img 
                src={selectedItem.url} 
                alt={selectedItem.title} 
                className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
              />
            ) : (
              <div className="relative w-full" style={{paddingBottom: '56.25%'}}>
                <video 
                  src={selectedItem.url} 
                  controls 
                  autoPlay 
                  className="absolute inset-0 w-full h-full rounded-lg"
                >
                  Your browser does not support the video tag.
                </video>
              </div>
            )}
            <div className="mt-4 text-white">
              <p className="text-xl font-medium">{selectedItem.title}</p>
            </div>
          </div>
          
          {/* Close Button */}
          <button 
            onClick={closeLightbox}
            className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors duration-300"
          >
            <span className="sr-only">Close</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      )}
    </section>
  );
};

export default GallerySection;
