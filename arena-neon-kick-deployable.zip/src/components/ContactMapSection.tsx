
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Facebook,
  Instagram,
  Youtube,
  MessageSquare
} from 'lucide-react';

const ContactMapSection = () => {
  const [visibleSection, setVisibleSection] = useState(false);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setVisibleSection(true);
        }
      },
      { threshold: 0.1 }
    );
    
    const section = document.querySelector('#contact');
    if (section) {
      observer.observe(section);
    }
    
    return () => {
      if (section) {
        observer.unobserve(section);
      }
    };
  }, []);

  return (
    <section id="contact" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1)_0,transparent_8px)] bg-[length:24px_24px]"></div>
        <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-neon-blue rounded-full blur-3xl opacity-10"></div>
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-neon-green rounded-full blur-3xl opacity-10"></div>
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">CONTACT US</h2>
          <p className="section-subheading max-w-3xl mx-auto">
            Have questions or need more information? Get in touch with us and we'll be happy to help.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Map Section */}
          <div 
            className={`transition-all duration-1000 transform ${
              visibleSection ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'
            }`}
          >
            <div className="glass-card p-1 rounded-lg h-full overflow-hidden">
              {/* Map container - You would replace this with actual map implementation */}
              <div className="relative w-full h-96 lg:h-full rounded-lg overflow-hidden">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d116153.11111365932!2d88.55088524115033!3d24.36873174475232!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fbefa96a38d031%3A0x10f93a950ed6f410!2sRajshahi%2C%20Bangladesh!5e0!3m2!1sen!2sus!4v1646154242232!5m2!1sen!2sus" 
                  width="100%" 
                  height="100%" 
                  allowFullScreen 
                  loading="lazy"
                  title="Rajshahi Turf Arena Location"
                  className="absolute inset-0"
                />
                
                {/* Pin Animation */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="relative">
                    <MapPin size={40} className="text-neon-green z-10 relative" />
                    <div className="absolute top-0 left-0 w-full h-full animate-ripple rounded-full bg-neon-green/30"></div>
                  </div>
                </div>
                
                {/* Map Controls Overlay */}
                <div className="absolute top-4 right-4 flex flex-col space-y-2">
                  <button className="w-10 h-10 bg-black/70 flex items-center justify-center rounded-full text-white hover:bg-black transition-colors">+</button>
                  <button className="w-10 h-10 bg-black/70 flex items-center justify-center rounded-full text-white hover:bg-black transition-colors">-</button>
                  <button className="w-10 h-10 bg-black/70 flex items-center justify-center rounded-full text-white hover:bg-black transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
                    </svg>
                  </button>
                </div>
                
                {/* Location Info Card */}
                <div className="absolute bottom-4 left-4 glass-card p-4 rounded-lg max-w-xs">
                  <h3 className="text-white font-bold mb-2">Rajshahi Turf Arena</h3>
                  <p className="text-gray-300 text-sm mb-2">Rajshahi Stadium Complex, Rajshahi, Bangladesh</p>
                  <a 
                    href="https://goo.gl/maps/yourMapLink" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-neon-blue text-sm hover:underline"
                  >
                    Get Directions
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact Form & Info */}
          <div 
            className={`transition-all duration-1000 transform ${
              visibleSection ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
            }`}
            style={{ transitionDelay: '0.2s' }}
          >
            <div className="glass-card p-6 rounded-lg h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <ContactInfoItem 
                  icon={<MapPin size={20} />} 
                  title="Address"
                  content={<p>Rajshahi Stadium Complex, Rajshahi, Bangladesh</p>}
                />
                <ContactInfoItem 
                  icon={<Phone size={20} />} 
                  title="Phone"
                  content={<p>+880 1XXX-XXXXXX</p>}
                />
                <ContactInfoItem 
                  icon={<Mail size={20} />} 
                  title="Email"
                  content={<p>info@rajshahiturf.com</p>}
                />
                <ContactInfoItem 
                  icon={<Clock size={20} />} 
                  title="Hours"
                  content={<p>9:00 AM - 11:00 PM<br />Open Every Day</p>}
                />
              </div>
              
              {/* Social Media */}
              <div className="flex justify-center space-x-4 mb-8">
                <a 
                  href="https://facebook.com" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-700 text-white hover:border-neon-blue hover:text-neon-blue transition-colors"
                >
                  <Facebook size={20} />
                </a>
                <a 
                  href="https://instagram.com" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-700 text-white hover:border-neon-blue hover:text-neon-blue transition-colors"
                >
                  <Instagram size={20} />
                </a>
                <a 
                  href="https://youtube.com" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-700 text-white hover:border-neon-blue hover:text-neon-blue transition-colors"
                >
                  <Youtube size={20} />
                </a>
              </div>
              
              {/* Contact Form */}
              <h3 className="text-xl font-bold text-white mb-4">Send Us a Message</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Your Name</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-neon-green"
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 mb-2">Your Email</label>
                    <input 
                      type="email" 
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-neon-green"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-300 mb-2">Subject</label>
                  <input 
                    type="text" 
                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-neon-green"
                    placeholder="Enter subject"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 mb-2">Message</label>
                  <textarea 
                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-neon-green"
                    placeholder="Enter your message"
                    rows={4}
                  />
                </div>
                <Button className="neo-button w-full">
                  Send Message
                </Button>
              </form>
              
              {/* WhatsApp Contact */}
              <div className="mt-8 flex items-center justify-center">
                <a 
                  href="https://wa.me/880XXXXXXXXXX" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center px-6 py-3 bg-[#25D366] text-white rounded-lg hover:bg-opacity-90 transition-colors"
                >
                  <MessageSquare className="mr-2" size={20} />
                  <span>Chat on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ContactInfoItem = ({ 
  icon, 
  title, 
  content 
}: { 
  icon: React.ReactNode;
  title: string;
  content: React.ReactNode;
}) => (
  <div className="flex">
    <div className="mr-3 mt-1">
      <div className="w-8 h-8 bg-neon-green/10 rounded-full flex items-center justify-center text-neon-green">
        {icon}
      </div>
    </div>
    <div>
      <h4 className="text-white font-medium mb-1">{title}</h4>
      <div className="text-gray-400 text-sm">{content}</div>
    </div>
  </div>
);

export default ContactMapSection;
