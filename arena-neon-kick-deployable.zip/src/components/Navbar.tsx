import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  return <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-black/80 backdrop-blur-md py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center">
          <div className="relative">
            <img alt="Rajshahi Turf Arena Logo" className="h-10 w-auto" src="/lovable-uploads/fdb25486-b5ce-4733-9986-f5e40e2c50c7.jpg" />
            <div className="absolute -inset-1 rounded-full animate-pulse opacity-50 bg-neon-green blur-md -z-10"></div>
          </div>
          <h1 className="ml-3 text-xl font-bold neon-text-green">RAJSHAHI TURF </h1>
        </div>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <NavLink href="#home">Home</NavLink>
          <NavLink href="#about">About</NavLink>
          <NavLink href="#booking">Book Now</NavLink>
          <NavLink href="#gallery">Gallery</NavLink>
          <NavLink href="#testimonials">Reviews</NavLink>
          <NavLink href="#pricing">Pricing</NavLink>
          <NavLink href="#contact">Contact</NavLink>
          <Button className="neo-button">Book Your Game</Button>
        </div>
        
        {/* Mobile Menu Button */}
        <button className="md:hidden text-white focus:outline-none" onClick={() => setMenuOpen(!menuOpen)}>
          <div className="w-6 flex flex-col items-end">
            <span className={`bg-neon-green h-0.5 rounded-full transition-all duration-300 ${menuOpen ? 'w-6 transform rotate-45 translate-y-1.5' : 'w-6 mb-1.5'}`}></span>
            <span className={`bg-neon-green h-0.5 rounded-full transition-all duration-300 ${menuOpen ? 'opacity-0 w-6' : 'w-4 mb-1.5'}`}></span>
            <span className={`bg-neon-green h-0.5 rounded-full transition-all duration-300 ${menuOpen ? 'w-6 transform -rotate-45 -translate-y-1.5' : 'w-5'}`}></span>
          </div>
        </button>
      </div>
      
      {/* Mobile Menu Panel */}
      <div className={`md:hidden absolute w-full bg-black/95 backdrop-blur-md transition-all duration-300 ${menuOpen ? 'max-h-screen py-4 opacity-100' : 'max-h-0 py-0 opacity-0 overflow-hidden'}`}>
        <div className="container mx-auto px-4 flex flex-col space-y-4">
          <MobileNavLink href="#home" onClick={() => setMenuOpen(false)}>Home</MobileNavLink>
          <MobileNavLink href="#about" onClick={() => setMenuOpen(false)}>About</MobileNavLink>
          <MobileNavLink href="#booking" onClick={() => setMenuOpen(false)}>Book Now</MobileNavLink>
          <MobileNavLink href="#gallery" onClick={() => setMenuOpen(false)}>Gallery</MobileNavLink>
          <MobileNavLink href="#testimonials" onClick={() => setMenuOpen(false)}>Reviews</MobileNavLink>
          <MobileNavLink href="#pricing" onClick={() => setMenuOpen(false)}>Pricing</MobileNavLink>
          <MobileNavLink href="#contact" onClick={() => setMenuOpen(false)}>Contact</MobileNavLink>
          <Button className="neo-button w-full">Book Your Game</Button>
        </div>
      </div>
    </nav>;
};
const NavLink = ({
  href,
  children
}: {
  href: string;
  children: React.ReactNode;
}) => <a href={href} className="text-white hover:text-neon-green transition-all duration-300 relative group">
    <span>{children}</span>
    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-neon-green transition-all duration-300 group-hover:w-full"></span>
  </a>;
const MobileNavLink = ({
  href,
  onClick,
  children
}: {
  href: string;
  onClick: () => void;
  children: React.ReactNode;
}) => <a href={href} onClick={onClick} className="text-white hover:text-neon-green py-2 transition-all duration-300 border-b border-white/10">
    {children}
  </a>;
export default Navbar;