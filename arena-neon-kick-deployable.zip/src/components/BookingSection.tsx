
import { useState, useEffect } from 'react';
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type TimeSlot = {
  id: number;
  time: string;
  isAvailable: boolean;
};

const BookingSection = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<number | null>(null);
  const [visibleItems, setVisibleItems] = useState<string[]>([]);
  const [formData, setFormData] = useState({ name: "", email: "" });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            setVisibleItems(prev => [...prev, id]);
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = document.querySelectorAll('.booking-animate');
    elements.forEach(el => observer.observe(el));

    return () => {
      elements.forEach(el => observer.unobserve(el));
    };
  }, []);

  const generateTimeSlots = (): TimeSlot[] => {
    const slots = [];
    for (let hour = 6; hour <= 23; hour++) {
      slots.push({
        id: slots.length,
        time: `${hour % 12 || 12}:00 ${hour < 12 ? 'AM' : 'PM'}`,
        isAvailable: Math.random() > 0.3
      });
      slots.push({
        id: slots.length,
        time: `${hour % 12 || 12}:30 ${hour < 12 ? 'AM' : 'PM'}`,
        isAvailable: Math.random() > 0.3
      });
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Booking submitted:", { ...formData, date, time: timeSlots[selectedTimeSlot || 0].time });
    setSubmitted(true);
  };

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto booking-animate" id="booking">
      <h2 className="text-3xl font-bold text-center mb-6">Book Your Session</h2>

      {submitted ? (
        <div className="text-center text-green-600 text-xl">Booking submitted successfully!</div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <input
              type="text"
              placeholder="Your Name"
              required
              className="p-3 border rounded w-full"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
            <input
              type="email"
              placeholder="Email Address"
              required
              className="p-3 border rounded w-full"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div>
            <p className="mb-2 font-semibold">Select a Date:</p>
            <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
          </div>

          <div>
            <p className="mb-2 font-semibold">Select a Time Slot:</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-h-64 overflow-y-auto">
              {timeSlots.map(slot => (
                <Button
                  key={slot.id}
                  type="button"
                  onClick={() => setSelectedTimeSlot(slot.id)}
                  className={cn(
                    "text-sm",
                    selectedTimeSlot === slot.id ? "bg-blue-600 text-white" : "bg-gray-200 text-black",
                    !slot.isAvailable && "opacity-50 cursor-not-allowed"
                  )}
                  disabled={!slot.isAvailable}
                >
                  {slot.time}
                </Button>
              ))}
            </div>
          </div>

          <div className="text-center">
            <Button type="submit" disabled={selectedTimeSlot === null}>
              Confirm Booking
            </Button>
          </div>
        </form>
      )}
    </section>
  );
};

export default BookingSection;
